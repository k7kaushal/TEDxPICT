import React ,{useEffect} from "react";
import Aos from "aos";
import "aos/dist/aos.css"
import './AboutUs.css';
import './AboutUs.css'
import  Yug from './components/Yug.jpeg'
import Rohit from './components/Rohit.jpeg'
import Anurag from './components/Anurag2.jpeg'
import Aashna from './components/Aashna.jpg'
import Bansi from './components/Bansi.jpg'
import Kirti from './components/Kirti.jpeg'
import Rathish from './components/Rathish.png'
import Manasi from './components/MG.jpg'
import Madhura from './components/Madhura.png'
import Sameer from './components/Sameer.jpg'
import Shlok from './components/Shlok.jpg'
import Smeet from './components/Smeet.jpeg'
import Devansh from './components/Devansh2.jpeg'
import { FaInstagram, FaLinkedin} from "react-icons/fa";
import Card from './Card.jsx'
import { Container, Col, Row, Button, CardGroup } from "react-bootstrap";
import styles from './ourteam.module.css'

function OurTeam() {
  useEffect(() => {
        Aos.init({duration:1000});
    }, []);
    return (
        <>  
        <div  className={styles.contq}>
           
              <h2 data-aos="fade-up" className={styles.h22}>Meet the&nbsp;<font color="red">Team</font></h2>
              
          
            
              
              <CardGroup data-aos="flip-right" >  
                <Card img={Devansh} name="Devansh Mundada" post="Licensee"  insta="https://www.instagram.com/deevaaanssh/" linkd="https://www.linkedin.com/in/devansh-mundada"/>
               
                <Card img={Smeet} name="Smeet  &nbsp;&nbsp;&nbsp; Ramteke" post="Co-Licensee" insta="https://www.instagram.com/smeetramteke/" linkd="https://www.linkedin.com/in/smeet-ramteke" />
                
                </CardGroup>
                
                <CardGroup data-aos="flip-left" className={styles.heads}>
                <Card img={Rohit} name="Rohit James" post="Design Head" insta="https://www.instagram.com/rohit_james12/" linkd="https://www.linkedin.com/in/rohit-james-6b93b4195/" />
                <Card img={Bansi} name="Bansi Shelke" post="Design Head" insta="https://www.instagram.com/bansi_vr/" linkd="https://www.linkedin.com/in/bansi-shelke-6282971b2" />
                <Card img={Aashna} name="Aashna Khater" post="Curations Head" insta="https://www.instagram.com/baali_4/" linkd="https://www.linkedin.com/in/aashnakhater" />
                <Card img={Anurag} name="Anurag Kelkar" post="Curations Head" insta="https://www.instagram.com/kelkar_anurag/" linkd="https://www.linkedin.com/in/anurag-kelkar-3470b51ab"/>
                </CardGroup>
              
                <CardGroup data-aos="flip-right"className={styles.heads}>
                <Card img={Shlok} name="Shlok Kalekar" post="Content Head" insta="https://www.instagram.com/shlokkalekar/" linkd="https://www.linkedin.com/in/shlok-kalekar-51496b213/"/>
                <Card  img={Yug}  name="Yugandhar Hujare"   post="Content Head" insta="https://www.instagram.com/yugandhar_hujare/" linkd="https://www.linkedin.com/in/yugandhar-hujare-94a4a61ab" />
                <Card img={Sameer}name="Sameer Memon" post="Branding Head" insta="https://www.instagram.com/memon.sameer_/" linkd="https://www.linkedin.com/in/sameer-memon-0019ab1a9" />
                <Card img={Manasi} name="Manasi Ganu" post="Branding Head" insta="https://www.instagram.com/__maaaanasi_/" linkd="https://www.linkedin.com/in/manasi-ganu-194b431b9" />
                </CardGroup>
               
               <CardGroup data-aos="flip-left" className={styles.heads}>
               <Card img={Rathish} name="Rathish Kumar" post="Operations Head" insta="https://www.instagram.com/rxth1sh/" linkd="https://www.linkedin.com/in/rathish-kumar-6531361b0"/>
                <Card img={Madhura }name="Madhura Datkhile" post="Operations Head" insta="https://www.instagram.com/madhura._d" linkd="https://www.linkedin.com/in/madhura-datkhile-821a6b1a4" />
                <Card img={Kirti} name="Kirti Palve" post="Partnerships Head" insta="https://www.instagram.com/kirtii.i/" linkd="https://www.linkedin.com/in/kirti-palve"/>
                </CardGroup>
          </div>
      </> 
    )
}

export default OurTeam;
